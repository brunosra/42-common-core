/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_map_not_empty.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwell <student@42.fr>                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/16 23:04:48 by bschwell          #+#    #+#             */
/*   Updated: 2024/09/16 23:12:22 by bschwell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	ft_is_map_not_empty(t_map *map)
{
	ft_print_msg("checking if map is empty");
	if (map->data == NULL)
	{
		ft_print_err("Map is empty!");
		return (0);
	}
	ft_print_suc("Map is not empty!");
	return(1);	
}
