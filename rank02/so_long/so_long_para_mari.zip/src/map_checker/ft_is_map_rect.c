/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_map_rect.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwell <student@42.fr>                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/16 23:03:15 by bschwell          #+#    #+#             */
/*   Updated: 2024/09/16 23:05:08 by bschwell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	ft_is_map_rect(t_map *map)
{
	int i;
	size_t	curr_len;

	i = 0;
	curr_len = ft_strlen(map->data[i]);
	while (map->data[i])
	{
		if (curr_len != ft_strlen(map->data[i]))
		{
			ft_print_err("Map is not rectangular");
			return (0);
		}
		if (ft_strlen(map->data[i]) == 0)
		{
			ft_print_err("Map has empty line");
			return (0);
		}
		i++;
	}
	map->w = curr_len;
	ft_print_suc("Map is rectangular!");
	return(1);
}
