/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwell <student@42.fr>                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/15 11:21:27 by bschwell          #+#    #+#             */
/*   Updated: 2024/09/18 11:36:28 by bschwell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include <fcntl.h>
# include "../libs/libft/libft.h"
# include "../libs/minilibx-linux/mlx.h"

typedef struct s_map
{
	char	**data;
	int		w;
	int		h;
	int		n_c;
	int		n_e;
	int		n_p;
	int		p_x;
	int		p_y;
}				t_map;

/* Map Checking */
int		ft_open_map_file(char *file);
void	ft_create_game_map(char *file, t_map *map);
void	ft_printmap(t_map *map);

/* Outputting Functions */
void	ft_print_err(char *msg);
void	ft_print_wrn(char *msg);
void	ft_print_msg(char *msg);
void	ft_print_suc(char *msg);

/* Map Checker */
int		ft_is_collectible(t_map *map);
int		ft_is_exit(t_map *map);
int		ft_is_start(t_map *map);
int		ft_is_map_not_empty(t_map *map);
int		ft_is_map_surrounded_by_walls(t_map *map);
int		ft_is_map_rect(t_map *map);
int		ft_is_path_valid(t_map *map);
int		ft_is_specials(t_map *map);
int		ft_check_map(t_map *map);

# define ERROR_READ "unsuccessfull file read\n"
# define ERROR_RECTANGLE "map must be a rectangle\n"
# define ERROR_EMPTY_LINE "map has an empty line\n"
# define ERROR_WALLS "map must be surrounded by walls\n"
# define ERROR_GAME_INIT "game initialization failed\n"
# define ERROR_NO_ARG "no arguments"
# define ERROR_COL_ROW "map has less than 3 rows and/or 3 columns\n"
# define ERROR_EXIT "you must have exactly one exit\n"
# define ERROR_PLAYER "you must have exactly one player\n"
# define ERROR_COLLECT "you need at least one collectable\n"
# define ERROR_CHARS "map has invalid characters.\
 Allowed characters: 0, 1, P, C, E\n"
# define ERROR_FILE_READ "can\'t open file.\n"
# define ERROR_PATH "map does not have a valid path\n"
# define ERROR_MALLOC "memory allocation failed\n"
# define ERROR_IMG_LOAD "could not load image %s\n"
# define GAME_COMPLETE "Congratulations! You completed the game!\n"

#endif