/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_there_exit.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwell <student@42.fr>                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/16 23:07:13 by bschwell          #+#    #+#             */
/*   Updated: 2024/09/17 20:12:38 by bschwell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	ft_is_exit(t_map *map)
{
	int i;
	int j;
	int	c;

	i = 0;
	c = 0;
	while (i < map->h)
	{
		j = 0;
		while (j < map->w)
		{
			if (map->data[i][j++] == 'E')
				c++;
		}
		i++;
	}
	if (c != 1)
	{
		ft_print_err("Map has error on exits");
		return (0);
	}
	ft_print_suc("Map has only one exit!");
	return (1);
}
