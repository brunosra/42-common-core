/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bschwell <student@42.fr>                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/15 11:27:23 by bschwell          #+#    #+#             */
/*   Updated: 2024/09/16 23:10:16 by bschwell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

/* typedef struct	s_data {
	void	*img;
	char	*addr;
	int		bits_per_pixel;
	int		line_length;
	int		endian;
}	            t_data; */

/* void	my_mlx_pixel_put(t_data *data, int x, int y, int color)
{
	char	*dst;

	dst = data->addr + (y * data->line_length + x * (data->bits_per_pixel / 8));
	*(unsigned int*)dst = color;
} */

int	main(int argc, char **argv)
{
	t_map	*map;

	map = (t_map*) ft_calloc(1, sizeof(t_map));
	if (argc == 2)
	{
		ft_create_game_map(argv[1], map);
		if (ft_check_map(map) == 0)
		{
			ft_print_err("Map has errors!");
			return (2);
		}
		ft_printmap(map);
	}
	else
		ft_print_err("Usage: ./so_long "C_CY"[file_path_map]");
	return (0);
}

/* void	*mlx;
	void    *mlx_win;
	t_data	img;

	mlx = mlx_init();
	mlx_win = mlx_new_window(mlx, 800, 600, "Hello!");
	img.img = mlx_new_image(mlx, 800, 600);
	img.addr = mlx_get_data_addr(img.img, &img.bits_per_pixel, &img.line_length, &img.endian);
	my_mlx_pixel_put(&img, 5, 5, 0x00FFFF00);
	my_mlx_pixel_put(&img, 10, 5, 0x00FFFF00);
	my_mlx_pixel_put(&img, 5, 10, 0x00FFFF00);
	my_mlx_pixel_put(&img, 10, 10, 0x00FFFF00);
	mlx_put_image_to_window(mlx, mlx_win, img.img, 0, 0);
	mlx_loop(mlx); */